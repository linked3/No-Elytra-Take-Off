This datapack not only enhances combat difficulty but also addresses the issue of Elytras being overpowered, preventing easy escape from fights without active engagement.

When skeletons or zombies hit you, you will start limping and won't be able to activate your elytra for 10 seconds. Zombies will give you the Hunger effect with every hit, causing you to lose 3 drumsticks. When you approach creepers, they will slow you down, making it impossible to take off. Spiders can now trap you in their cobwebs when attacking.

This datapack is inspired by the mob mechanics found in [True Survival](https://modrinth.com/datapack/true-survival).